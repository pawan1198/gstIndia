## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse=TRUE, comment="#>", fig.width=7, fig.height=4.5)

## ----load---------------------------------------------------------------------
library(gstIndia)
library(data.table)

## ----catalogue----------------------------------------------------------------
gst_catalogue()

## ----ref----------------------------------------------------------------------
gst_years()      # available financial years
gst_states()     # 36+ states with codes and regions

## ----filter-------------------------------------------------------------------
# South India FY 2023-24, total column only
gst_filter(region = "South", financial_year = "2023-24", component = "total")

## ----top----------------------------------------------------------------------
gst_top_states(n = 10, financial_year = "2023-24")

## ----annual-------------------------------------------------------------------
# National totals per FY
gst_annual_summary(by = "national")[, .(financial_year, total)]

## ----share--------------------------------------------------------------------
gst_state_share(financial_year = "2023-24")[1:8]

## ----yoy----------------------------------------------------------------------
gst_yoy(state = "Maharashtra")[order(-month_date)][1:6,
  .(month, current, prior, pct_growth)]

## ----mix----------------------------------------------------------------------
gst_component_mix(state = "Gujarat", financial_year = "2023-24")

## ----net----------------------------------------------------------------------
# Net after refunds — top 10 states FY 2023-24
gst_net_collection(financial_year = "2023-24", by = "state")[order(-net)][1:10]

## ----compliance---------------------------------------------------------------
# GSTR-3B average compliance by region FY 2023-24
gst_compliance_trend("GSTR-3B", by = "region", financial_year = "2023-24")[
  order(-avg_filing_pct)]

## ----low-compliance-----------------------------------------------------------
# States below 90% GSTR-1 compliance in FY 2022-23
gst_low_compliance_states("GSTR-1", threshold = 0.90, financial_year = "2022-23")

## ----ewb----------------------------------------------------------------------
# Top 5 states by intrastate EWB count FY 2023-24
ewb_top_states(n = 5, financial_year = "2023-24", direction = "intrastate")

## ----ewb-value----------------------------------------------------------------
# Top 5 by interstate outgoing assessable value
ewb_top_states(n = 5, metric = "assessable_value",
               direction = "interstate_out", financial_year = "2023-24")

## ----igst---------------------------------------------------------------------
igst_settlement_summary(financial_year = "2023-24", by = "state")[order(-total)][1:8]

## ----reg----------------------------------------------------------------------
# Top 10 states by normal taxpayer registrations
gst_registration_summary()[order(-normal)][1:10]

## ----profile------------------------------------------------------------------
# Taxpayer constitution profile
gst_taxpayer_profile[order(-total_taxpayers)]

## ----gross-net----------------------------------------------------------------
gross_net_collection[, .(month, gross_domestic_cur, refund_cur)]

## ----plot, eval=FALSE---------------------------------------------------------
#  library(ggplot2)
#  
#  top5 <- gst_top_states(n = 5, financial_year = "2023-24")$state
#  dt   <- gst_filter(state = top5,
#                     financial_year = c("2022-23","2023-24","2024-25"),
#                     component = "total")
#  
#  ggplot(dt, aes(month_date, total / 1e3, colour = state)) +
#    geom_line(linewidth = 0.8) +
#    scale_y_continuous(labels = scales::comma_format(suffix = "K Cr")) +
#    labs(title    = "Monthly GST Collection — Top 5 States",
#         subtitle = "FY 2022-23 to 2024-25  |  Rs. '000 Crore",
#         x = NULL, y = NULL, colour = NULL,
#         caption  = "Source: Ministry of Finance, GoI") +
#    theme_minimal(base_size = 12) +
#    theme(legend.position = "bottom")

